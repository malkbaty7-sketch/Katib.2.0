# بناء المكتبة الجاهزة

الملفات:
- `books.csv` — بيانات الكتب (العنوان، المؤلف، التصنيف، الفئة `free|premium`، الترخيص، المصدر).
- `texts/` — نصوص الكتب (`<id>.md` أو `.txt` أو `.docx` أو `.pdf`).
- `fetch_books.py` — يجلب الكتب ذات المصدر `wikisource` إلى `texts/`.
- `build_catalog.py` — يحوّل `texts/` إلى `docs/library/catalog.json` و`docs/library/books/*.json`.

## الطريقة الأسهل (بدون تثبيت شيء)
1. ارفع أي ملفات كتب يدوية إلى `tools/library/texts/` باسم `id` الكتاب من `books.csv`.
2. في GitHub: Actions ← **Build ready library** ← Run workflow.
3. يجلب الكتب المفتوحة ويبني الفهرس ويحفظ الناتج في `docs/library` تلقائياً.
4. فعّل GitHub Pages (Settings ← Pages ← `main` ← `/docs`).
5. أضف متغيراً `CATALOG_URL` في Settings ← Variables:
   `https://malkbaty7-sketch.github.io/<اسم-المستودع>/library/catalog.json`

## محلياً
```bash
pip install requests pypdf
python tools/library/fetch_books.py      # الكتب المفتوحة
python tools/library/build_catalog.py    # الفهرس
```

## إن لم يُعثر على كتاب
يطبع `fetch_books.py` اقتراحات بحث. صحّح `source_ref` في `books.csv`،
أو ضع النص يدوياً في `texts/<id>.md`.  للبحث: `python fetch_books.py --search "كلمة"`.

## الحقوق (مهم)
النص الأصلي القديم ملك عام، لكن **التحقيق والشروح الحديثة قد تكون محمية**.
استخدم نصوصاً غير محققة أو من مصادر تصرّح بالملك العام، وتحقق من حكم بلدك قبل النشر.
عمود `license` يظهر للمستخدم في بطاقة الكتاب.

## الكتب المدفوعة لاحقاً
ضع `premium` في عمود `tier`. تظهر مقفلة في التطبيق. الحماية الفعلية تحتاج خادماً
وتحققاً من الاشتراك (مرحلة مستقلة)، فلا تضع كتباً مدفوعة فعلية في `docs/` العامة.
