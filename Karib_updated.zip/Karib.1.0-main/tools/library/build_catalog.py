#!/usr/bin/env python3
"""بناء فهرس المكتبة الجاهزة من books.csv + الملفات في texts/

يدعم: .md .txt .docx .pdf  (اسم الملف = id الكتاب، مثال texts/al-bukhala.md)
الناتج: docs/library/catalog.json  و  docs/library/books/<id>.json

الاستخدام:  python build_catalog.py
"""
import csv, json, os, re, subprocess, sys, time, zipfile, xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", ".."))
OUT = os.path.join(ROOT, "docs", "library")
TARGET_WORDS = 2500  # حجم الفصل عند غياب العناوين


def read_text(path):
    ext = os.path.splitext(path)[1].lower()
    if ext in (".md", ".txt"):
        return open(path, encoding="utf-8-sig").read()
    if ext == ".docx":
        with zipfile.ZipFile(path) as z:
            root = ET.fromstring(z.read("word/document.xml"))
        ns = {"w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
        paras = []
        for p in root.iter("{%s}p" % ns["w"]):
            txt = "".join(t.text or "" for t in p.iter("{%s}t" % ns["w"]))
            style = p.find("w:pPr/w:pStyle", ns)
            sid = style.get("{%s}val" % ns["w"]) if style is not None else ""
            paras.append(("# " + txt) if sid.lower().startswith(("heading", "title")) and txt else txt)
        return "\n\n".join(paras)
    if ext == ".pdf":
        try:
            return subprocess.run(["pdftotext", "-layout", path, "-"], capture_output=True,
                                  text=True, check=True).stdout
        except Exception:
            from pypdf import PdfReader  # pip install pypdf
            return "\n\n".join((pg.extract_text() or "") for pg in PdfReader(path).pages)
    raise ValueError(f"صيغة غير مدعومة: {ext}")


def words(s):
    return len(s.split())


def split_chapters(text, book_title):
    text = text.replace("\r\n", "\n").strip()
    parts = re.split(r"^(?:#{1,2})\s+(.+?)\s*$", text, flags=re.M)
    chapters = []
    if len(parts) > 2:
        if parts[0].strip():
            chapters.append(("مقدمة", parts[0].strip()))
        for i in range(1, len(parts), 2):
            body = parts[i + 1].strip()
            if body:
                chapters.append((parts[i].strip(), body))
    else:
        paras = [p for p in re.split(r"\n\s*\n", text) if p.strip()]
        buf, n, idx = [], 0, 1
        for p in paras:
            buf.append(p); n += words(p)
            if n >= TARGET_WORDS:
                chapters.append((f"الجزء {idx}", "\n\n".join(buf))); buf, n, idx = [], 0, idx + 1
        if buf:
            chapters.append((f"الجزء {idx}", "\n\n".join(buf)))
    # ادمج الفصول القصيرة جداً (< 80 كلمة) مع اللاحق
    merged = []
    for title, body in chapters:
        if merged and words(merged[-1][1]) < 80:
            pt, pb = merged.pop()
            merged.append((title, pb + "\n\n" + body))
        else:
            merged.append((title, body))
    return merged or [(book_title, text)]


def main():
    os.makedirs(os.path.join(OUT, "books"), exist_ok=True)
    with open(os.path.join(HERE, "books.csv"), encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    catalog, missing = [], []
    for r in rows:
        path = next((os.path.join(HERE, "texts", r["id"] + e) for e in (".md", ".txt", ".docx", ".pdf")
                     if os.path.exists(os.path.join(HERE, "texts", r["id"] + e))), None)
        if not path:
            missing.append(r["id"]); continue
        chapters = split_chapters(read_text(path), r["title"])
        chs = [{"id": f'{r["id"]}-{i}', "title": t, "plainText": b, "wordCount": words(b)}
               for i, (t, b) in enumerate(chapters, 1)]
        total = sum(c["wordCount"] for c in chs)
        book_file = os.path.join(OUT, "books", r["id"] + ".json")
        with open(book_file, "w", encoding="utf-8") as f:
            json.dump({"id": r["id"], "chapters": chs}, f, ensure_ascii=False, separators=(",", ":"))
        catalog.append({
            "id": r["id"], "title": r["title"], "author": r["author"], "category": r["category"],
            "tier": r["tier"] or "free", "license": r["license"], "description": r["description"],
            "coverGradient": r["gradient"] or "from-amber-700 via-amber-800 to-stone-900",
            "wordCount": total, "chapterCount": len(chs),
            "file": f"books/{r['id']}.json", "sizeBytes": os.path.getsize(book_file),
        })
    with open(os.path.join(OUT, "catalog.json"), "w", encoding="utf-8") as f:
        json.dump({"version": int(time.time()), "books": catalog}, f, ensure_ascii=False, indent=1)
    print(f"✓ {len(catalog)} كتاباً في الفهرس → {os.path.relpath(OUT, ROOT)}/catalog.json")
    if missing:
        print("⚠ بلا نص (لم تُدرج):", ", ".join(missing))


if __name__ == "__main__":
    main()
