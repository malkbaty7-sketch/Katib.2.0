#!/usr/bin/env python3
"""جلب نصوص الكتب من ويكي مصدر العربية (ملك عام) إلى tools/library/texts/<id>.md

الاستخدام:
    python fetch_books.py                 # يجلب كل الكتب ذات المصدر wikisource
    python fetch_books.py --id al-bukhala # كتاب واحد
    python fetch_books.py --search "البخلاء"   # للبحث عن العنوان الصحيح في ويكي مصدر

ملاحظات:
- يتطلب اتصالاً بالإنترنت (مكتبة requests فقط: pip install requests).
- إن لم يُعثر على الصفحة يطبع اقتراحات بحث؛ صحّح عمود source_ref في books.csv وأعد التشغيل.
- تحقق دائماً من أن النص المجلوب غير محقَّق/مشروح بحقوق خاصة.
"""
import argparse, csv, os, re, sys, time

API = "https://ar.wikisource.org/w/api.php"
HERE = os.path.dirname(os.path.abspath(__file__))
UA = {"User-Agent": "KatibLibraryBuilder/1.0 (https://github.com/malkbaty7-sketch)"}


def api(params):
    import requests
    params = {**params, "format": "json", "formatversion": "2"}
    for attempt in range(4):
        try:
            r = requests.get(API, params=params, headers=UA, timeout=30)
            r.raise_for_status()
            return r.json()
        except Exception as e:  # noqa
            if attempt == 3:
                raise
            time.sleep(1.5 * (attempt + 1))


def search_titles(query, limit=8):
    data = api({"action": "query", "list": "search", "srsearch": query,
                "srnamespace": 0, "srlimit": limit})
    return [h["title"] for h in data.get("query", {}).get("search", [])]


def get_wikitext(title):
    data = api({"action": "query", "prop": "revisions", "rvprop": "content",
                "rvslots": "main", "titles": title, "redirects": 1})
    pages = data.get("query", {}).get("pages", [])
    if not pages or pages[0].get("missing"):
        return None
    return pages[0]["revisions"][0]["slots"]["main"]["content"]


def list_subpages(title):
    out, cont = [], {}
    while True:
        data = api({"action": "query", "list": "allpages", "apprefix": title + "/",
                    "apnamespace": 0, "aplimit": 500, **cont})
        out += [p["title"] for p in data.get("query", {}).get("allpages", [])]
        if "continue" in data:
            cont = data["continue"]
        else:
            return out


def natural_key(s):
    return [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", s)]


def clean_wikitext(t):
    """تنظيف مبسّط لنص ويكي إلى نص عادي."""
    t = re.sub(r"<!--.*?-->", "", t, flags=re.S)
    t = re.sub(r"<ref[^>]*?/>|<ref[^>]*?>.*?</ref>", "", t, flags=re.S)
    t = re.sub(r"\{\{[^{}]*\}\}", "", t)          # قوالب بسيطة (تكرار للتداخل)
    t = re.sub(r"\{\{[^{}]*\}\}", "", t)
    t = re.sub(r"\[\[(?:[^\]|]*\|)?([^\]]*)\]\]", r"\1", t)   # روابط داخلية
    t = re.sub(r"\[https?://\S+\s+([^\]]+)\]", r"\1", t)     # روابط خارجية
    t = re.sub(r"'{2,}", "", t)                              # غامق/مائل
    t = re.sub(r"<[^>]+>", "", t)                            # وسوم HTML
    t = re.sub(r"^=+\s*(.*?)\s*=+\s*$", r"## \1", t, flags=re.M)  # عناوين
    t = re.sub(r"\n{3,}", "\n\n", t)
    return t.strip()


def fetch_book(row):
    title = row["source_ref"]
    main = get_wikitext(title)
    if main is None:
        hints = search_titles(title)
        return None, hints
    subs = sorted(list_subpages(title), key=natural_key)
    parts = [f"# {row['title']}\n"]
    body = clean_wikitext(main)
    if body:
        parts.append(body)
    for i, sp in enumerate(subs, 1):
        txt = get_wikitext(sp)
        if not txt:
            continue
        heading = sp.split("/", 1)[1]
        parts.append(f"\n\n# {heading}\n\n{clean_wikitext(txt)}")
        if i % 20 == 0:
            print(f"   … {i}/{len(subs)} صفحة", flush=True)
            time.sleep(0.3)
    return "\n".join(parts).strip() + "\n", []


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--id")
    ap.add_argument("--search")
    a = ap.parse_args()
    if a.search:
        for t in search_titles(a.search):
            print(t)
        return
    os.makedirs(os.path.join(HERE, "texts"), exist_ok=True)
    with open(os.path.join(HERE, "books.csv"), encoding="utf-8") as f:
        rows = [r for r in csv.DictReader(f) if r["source"] == "wikisource"]
    if a.id:
        rows = [r for r in rows if r["id"] == a.id]
    failed = []
    for r in rows:
        out = os.path.join(HERE, "texts", r["id"] + ".md")
        if os.path.exists(out) and os.path.getsize(out) > 2000:
            print(f"✓ موجود: {r['title']}")
            continue
        print(f"↓ {r['title']} ({r['source_ref']})", flush=True)
        try:
            text, hints = fetch_book(r)
        except Exception as e:
            print(f"   ✗ خطأ اتصال: {e}")
            failed.append(r["id"]); continue
        if text is None:
            print("   ✗ لم توجد الصفحة. اقتراحات:", " | ".join(hints) or "لا شيء")
            failed.append(r["id"]); continue
        open(out, "w", encoding="utf-8").write(text)
        print(f"   ✓ {len(text.split())} كلمة")
    if failed:
        print("\nلم تكتمل:", ", ".join(failed))
        print("صحّح source_ref أو ضع الملف يدوياً في texts/<id>.md ثم شغّل build_catalog.py")
        sys.exit(1)


if __name__ == "__main__":
    main()
